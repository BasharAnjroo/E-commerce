<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreAttribute_setRequest;
use App\Http\Resources\Attribute_SetResource;
use App\Models\AttributeSet;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Symfony\Component\HttpFoundation\Response;

class AttributeSetController extends Controller
{
     /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        abort_if(Gate::denies('AttributeSet_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return new Attribute_SetResource(AttributeSet::with('attributes.values')->get());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreAttribute_setRequest $request)
    {
        abort_if(Gate::denies('AttributeSet_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');
            $Attribute = AttributeSet::create([
                'name' => $request->name,
            ]);
            foreach($request->attribute_id as $id_att){
            $Attribute->attributes()->attach($id_att);
            }
            return (new Attribute_SetResource($Attribute))
            ->response()
            ->setStatusCode(Response::HTTP_CREATED);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
       abort_if(Gate::denies('AttributeSet_show'),Response::HTTP_FORBIDDEN,'403 Forbidden');
       return new Attribute_SetResource(AttributeSet::findOrFail($id)->attributes()->with('values')->get());
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        abort_if(Gate::denies('AttributeSet_edit'),Response::HTTP_FORBIDDEN,'403 Forbidden');

        $Attribute = AttributeSet::findOrFail($id);
        $Attribute->update($request->all());
        foreach($request->attribute_id as $id_att){
            $Attribute->attributes()->sync($id_att);
            }
        return (new Attribute_SetResource($Attribute))
        ->response()
        ->setStatusCode(Response::HTTP_ACCEPTED);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        abort_if(Gate::denies('AttributeSet_delete'),Response::HTTP_FORBIDDEN,'403 Forbidden');

        $Attribute = AttributeSet::findOrFail($id);
        $Attribute->delete();
        return response()->json(response(null, Response::HTTP_NO_CONTENT));
    }
}
