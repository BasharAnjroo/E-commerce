<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreAttributeRequest;
use App\Http\Requests\UpdateAttributeRequest;
use App\Http\Resources\AttributeResource;
use App\Models\Attribute;
use App\Models\AttributeValue;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Symfony\Component\HttpFoundation\Response;
class AttributeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        abort_if(Gate::denies('Attribute_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return new AttributeResource(Attribute::with('values')->get());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreAttributeRequest $request)
    {
        abort_if(Gate::denies('Attribute_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

            $Attribute = Attribute::create([
                'name' => $request->name,
                'type' => 'dropdown',
            ]);
            return (new AttributeResource($Attribute))
            ->response()
            ->setStatusCode(Response::HTTP_CREATED);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
       abort_if(Gate::denies('Attribute_show'),Response::HTTP_FORBIDDEN,'403 Forbidden');
       return new AttributeResource(Attribute::findOrFail($id)->values()->get());
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateAttributeRequest $request, $id)
    {
        abort_if(Gate::denies('Attribute_edit'),Response::HTTP_FORBIDDEN,'403 Forbidden');

        $Attribute = Attribute::findOrFail($id);
        $Attribute->update($request->all());
        return (new AttributeResource($Attribute))
        ->response()
        ->setStatusCode(Response::HTTP_ACCEPTED);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        abort_if(Gate::denies('Attribute_delete'),Response::HTTP_FORBIDDEN,'403 Forbidden');

        $Attribute = Attribute::findOrFail($id);
        $Attribute->values()->update(['attribute_id'=>null]);
        if($Attribute->sets()){
            $Attribute->sets()->detach();
        }
        if($Attribute->Product()){
            $Attribute->Product()->detach();
        }
        $Attribute->delete();
        return response()->json(response(null, Response::HTTP_NO_CONTENT));
    }
}
