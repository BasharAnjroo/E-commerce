<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Schema;

class CreateOrderProductTable extends Migration
{
    /**
     * Run the migrations.
     * @table order_product
     *
     * @return void
     */
    public function up()
    {
        Schema::create('order_product', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->integer('product_id')->unsigned();
            $table->integer('order_id')->unsigned();
            $table->string('name', 255)->nullable()->default(null);
            $table->string('sku', 100);
            $table->decimal('price', 13, 2)->nullable()->default(null);
            $table->decimal('tax', 13, 2)->nullable()->default(null);
            $table->decimal('total', 13, 2)->nullable()->default(null);
            $table->integer('quantity');
            $table->integer('currency_id')->unsigned();
            $table->string('currency', 10);
            $table->integer('attribute_set_id')->unsigned()->default(null);
            $table->foreign('order_id')
                ->references('id')->on('orders')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('product_id')
                ->references('id')->on('products')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('currency_id')
            ->references('id')->on('currencies')
            ->onDelete('no action')
            ->onUpdate('no action');

            $table->foreign('attribute_set_id')
            ->references('id')->on('attribute_sets')
            ->onDelete('no action')
            ->onUpdate('no action');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
     public function down()
     {
       Schema::dropIfExists('order_product');
     }
}
