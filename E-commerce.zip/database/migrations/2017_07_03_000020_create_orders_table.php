<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Schema;

class CreateOrdersTable extends Migration
{
    /**
     * Run the migrations.
     * @table orders
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->integer('user_id')->unsigned();
            $table->string('domain')->nullable();
            $table->integer('status_id')->unsigned();
            $table->string('status')->nullable();
            $table->integer('carrier_id')->unsigned();
            $table->string('shipping_name', 100)->nullable();
            $table->integer('currency_id')->unsigned();
            $table->string('currency', 10);
            $table->float('exchange_rate')->nullable();
            $table->mediumText('comment')->nullable()->default(null);
            $table->string('shipping_no', 50)->nullable()->default(null);
            $table->string('invoice_no', 50)->nullable()->default(null);
            $table->dateTime('invoice_date')->nullable()->default(null);
            $table->dateTime('delivery_date')->nullable()->default(null);
            $table->integer('payment_status')->default(1);
            $table->integer('subtotal')->nullable()->default(0);
            $table->decimal('total_discount', 13, 2)->nullable()->default(null);
            $table->integer('tax_id')->nullable()->default(0);
            $table->integer('total_tax')->nullable()->default(0);
            $table->decimal('total_shipping', 13, 2)->nullable()->default(null);
            $table->decimal('total', 13, 2)->nullable()->default(null);
            $table->string('name_sender', 100);
            $table->string('first_name_receiver', 100)->nullable();
            $table->string('last_name_receiver', 100)->nullable();
            $table->string('email', 150);
            $table->string('address1', 100)->nullable();
            $table->string('phone', 20)->nullable();
            $table->string('country', 10)->nullable()->default('SY');
            $table->string('payment_method', 100)->nullable();
            $table->string('user_agent', 255)->nullable();
            $table->string('ip', 100)->nullable();
            $table->string('transaction', 100)->nullable();
            $table->timestamps();

            $table->foreign('carrier_id')
                ->references('id')->on('carriers')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('currency_id')
                ->references('id')->on('currencies')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('tax_id')
                ->references('id')->on('taxes')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('user_id')
                ->references('id')->on('users')
                ->onDelete('no action')
                ->onUpdate('no action');


            $table->foreign('carrier_id')
            ->references('id')->on('carriers')
            ->onDelete('no action')
            ->onUpdate('no action');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
     public function down()
     {
       Schema::dropIfExists('orders');
     }
}
